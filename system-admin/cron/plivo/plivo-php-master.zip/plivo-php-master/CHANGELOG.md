# Change Log
All notable changes to this project will be documented in this file.

## [0.1.0] - 2015-03-13
### Changed
- Adheres to standard when extending parent class (match signatures)
- Makes the package installable via Composer
- Replaces HTTP_Request2 with Guzzle

## [1.1.5] - 2016-06-02
### Changed
- Added digitsMatchBLeg parameter to Dial XML
